package com.superapp.onboarding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnboardingApplicationTests {

	@Test
	void contextLoads() {
	}

}
